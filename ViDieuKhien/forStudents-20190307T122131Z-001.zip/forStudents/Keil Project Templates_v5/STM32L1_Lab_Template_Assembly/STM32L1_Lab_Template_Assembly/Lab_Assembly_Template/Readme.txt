Lab Assignment of STM32L Discovery Kit
=================================================


Student Name
-------------------------------------------------



Lab Status Summary
-------------------------------------------------



Something Cool Implemented in This Lab
-------------------------------------------------



Sugguestions for This Lab
-------------------------------------------------


