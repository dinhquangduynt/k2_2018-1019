/*
*********************************************************************************************************
* file:     main.c
* author:   xxxx, your-email@maine.edu
* date:     mmm-dd-2015
* version:  1.0
* compiler: MDK 5.12
* hardware: Discovery kit with STM32L152RCT6 MCU
* description: xxxx

// @note
//           This code is for the book "Embedded Systems with ARM Cortex-M3 
//           Microcontrollers in Assembly Language and C, Yifeng Zhu, 
//           ISBN-10: 0982692625.
// @attension
//           This code is provided for education purpose. The author shall not be 
//           held liable for any direct, indirect or consequential damages, for any 
//           reason whatever. More information can be found from book website: 
//           http://www.eece.maine.edu/~zhu/book
*********************************************************************************************************
*/

#include "stm32l1xx.h"
#include <stdint.h>
#include <stdio.h>

/*
*********************************************************************************************************
* STM32L1 Discovery Kit Pin Connections (STM32L152RBT6 or STM32L152RCT6)
*  USER Pushbutton  <------>  PA.0 (clock: RCC_AHBENR_GPIOAEN)
*  RESET Pushbutton <------>  RESET
*  Green LED (LD3)  <------>  PB.7 (clock: RCC_AHBENR_GPIOBEN)
*  Blue LED (LD4)   <------>  PB.6 (clock: RCC_AHBENR_GPIOBEN)
*  Touch Sensors    <------>  6 pins, PA.6,7 (group 2), PB.0,1 (group 3), PC.4,5 (group 9)
*  LCD (24 segments)<------>  28 pins, PA.1,2,3,8,9,10,15, 
*                                      PB.3,4,5,8,9,10,11,12,13,14,15
*                                      PC.0,1,2,3,6,7,8,9,10,11 
*  ST Link          <------>  PA.13,14
*  Boot 1           <------>  PB.2
*  Freely available pins: PA.5, PA.11, PA.12, PC.12, PD.2 
*  A GPIO pin is 5V tolerant and can sink or source up to 8 mA
*********************************************************************************************************
*/


#define bool _Bool

void LCD_Clock_Init(void);
void LCD_PIN_Init(void);
void LCD_Configure(void);
void LCD_Clear(void);
void LCD_DisplayString(uint8_t* ptr);
void LCD_bar(void);
void LCD_WriteChar(uint8_t* ch, bool point, bool colon, uint8_t position);
static void LCD_Conv_Char_Seg(uint8_t* c, bool point, bool colon, uint8_t* digit);
void LCD_Display_Name(void);
int TimingDelay;
int check=1;

// LCD_Clock_Init() is provided to you for both Lab Part 1 and Part 2.
void LCD_Clock_Init(void){
  // Note from STM32L Reference Manual:   
  // After reset, the RTC Registers (RTC registers and RTC backup registers) are protected
  // against possible stray write accesses. To enable access to the RTC Registers, proceed as
  // follows:
  // 1. Enable the power interface clock by setting the PWREN bits in the RCC_APB1ENR register.
  // 2. Set the DBP bit in the PWR_CR register (see Section 4.4.1).
  // 3. Select the RTC clock source through RTCSEL[1:0] bits in RCC_CSR register.
  // 4. Enable the RTC clock by programming the RTCEN bit in the RCC_CSR register.
  RCC->APB1ENR |= RCC_APB1ENR_PWREN;  // Power interface clock enable (Page 157)
  PWR->CR      |= PWR_CR_DBP;          // Disable Backup Domain write protection (Page 120-121)
  RCC->CSR      |= RCC_CSR_RTCSEL_LSI;  // LSI oscillator clock used as RTC clock (Page 165-167)
  //LSI clock varies due to frequency dispersion
  //RCC->CSR     |= RCC_CSR_RTCSEL_LSE;  // LSE oscillator clock used as RTC clock
  RCC->CSR     |= RCC_CSR_RTCEN;      // RTC clock enable (Page 167)
  
  /* Disable the write protection for RTC registers */
  RTC->WPR = 0xCA;          // RTC write protection register (WPR) (Page 537)
  RTC->WPR = 0x53;          // Write "0xCA" and "0x53" to unlock the write protection (Page 537)
  
  // Wait until MSI clock ready
  while((RCC->CR & RCC_CR_MSIRDY) == 0); // MSI Ready Flag is set by hardware (Page 140)
  
  /* Enable comparator clock LCD */
  RCC->APB1ENR |= RCC_APB1ENR_LCDEN; // (Page 158)
  
  /* Enable SYSCFG */
  RCC->APB2ENR |= RCC_APB2ENR_SYSCFGEN; // (Page 156)
  
  RCC->CSR |= RCC_CSR_LSION; // (Page 168)
  while( (RCC->CSR & RCC_CSR_LSIRDY) == 0 ); // (Page 168)
  
  /* Select LSI as LCD Clock Source */
  RCC->CSR &= ~RCC_CSR_RTCSEL_LSI;  // (Page 167)
  RCC->CSR |= RCC_CSR_RTCSEL_LSI;    // LSI oscillator clock used as RTC and LCD clock (Page 167) 
  RCC->CSR |= RCC_CSR_RTCEN;  // (Page 167)
}


void SysTick_Initialize(uint32_t ticks){
		SysTick->CTRL = 0; //Disable Systick IRQ and Systick Counter
		RCC->ICSCR &= ~(RCC_ICSCR_MSIRANGE); //Clear MSIRANGE of Internal Clock Source Calibration Register
		RCC->ICSCR |= RCC_ICSCR_MSIRANGE_6; //Set MSIRANGE to range 6 - 4.194 MHz
		RCC->CR |= RCC_CR_MSION; //Set MSION of Clock Control Register
		while(!(RCC->CR & (0x01<<9))); //Wait for MSIRDY set to 1, MSI oscillator ready
		SysTick->LOAD = ticks - 1;// Set LOAD
		NVIC_SetPriority(SysTick_IRQn,(1<<__NVIC_PRIO_BITS)-1); //Set Priority
		SysTick->VAL = 0;
		//Select processor clock
		SysTick->CTRL |= SysTick_CTRL_CLKSOURCE;
		//Enable IRQ and Systick Counter
		SysTick->CTRL |= SysTick_CTRL_ENABLE;
		//Enables Systick exception request
		SysTick->CTRL |= SysTick_CTRL_TICKINT;
		
		//Enable SYSCFG clock
		RCC->APB2ENR |= RCC_APB2ENR_SYSCFGEN;
		//Select PA.0 for EXTI line 0
		SYSCFG->EXTICR[0] &= ~(0x000F);
		//Set interrupt trigger to rising edge
		EXTI->RTSR |= EXTI_RTSR_TR0;
		//Enable EXTI line 0
		EXTI->IMR |= EXTI_IMR_MR0;
		//Set EXTI0 priority to 1
		NVIC_SetPriority(EXTI0_IRQn,1);
		//Enable EXIT0 Interupt
		NVIC_EnableIRQ(EXTI0_IRQn);
}
/* Delay Config */
void SysTick_Handler(void){
	if(TimingDelay != 0 ) TimingDelay--; 
}
void Delay(uint32_t nTime){
	TimingDelay = nTime;
	while(TimingDelay != 0);
}
/* Button Interrupt */
void EXTI0_IRQHandler(void){
	if(EXTI->PR & (1<<0)){//Check for EXTI0 interrupt flag
		if(check){
			LCD->FCR &= ~(0x7<<10);
			LCD->FCR |= 0x1<<10; // Set Contrast Min
			check=0;
		}
		else {
			LCD->FCR &= ~(0x7<<10);
			LCD->FCR |= 0x7<<10; // Set Contrast Max
			check =1;
		};
	EXTI->PR |= (1<<0);//Clear EXTI0 pending interrupt
	}
}
/* Blink LCD */
void LCD_Blink(){
		LCD_DisplayString("ARM");
		Delay(500);
		LCD_Clear();
		Delay(500);
		LCD_DisplayString("CORTEX");
		Delay(500);
		LCD_Clear();
		Delay(500);
		LCD_DisplayString("M3");
		Delay(500);
		LCD_Clear();
		Delay(500);
}
/* Main */
int main(void) {
	SysTick_Initialize(4194);
  LCD_Clock_Init();
  LCD_PIN_Init();
  LCD_Configure();
  while(1){
	if(check){
		LCD_Display_Name();
	}
		else LCD_Blink();
	};
}

/**************************************************************************************/
/*    Lab Part 1: Display your name                                                   */
/**************************************************************************************/
// This part is to display the first characters of your last name on the LCD. 
void LCD_PIN_Init(void){  
  // Implement your code here
	RCC->AHBENR |= RCC_AHBENR_GPIOAEN  | RCC_AHBENR_GPIOBEN | RCC_AHBENR_GPIOCEN ; // Enable clock of GPIO port A,B,C
	/* GPIOA mode alterfunc 15,10,9,8,3,2,1 */
	GPIOA->MODER &= ~(0xc03f00fc);
	GPIOA->MODER |= 0x802a00a8;
	/* Set alternate function mode 0xb port A */
	GPIOA->AFR[0] &= ~(0x0000fff0);
	GPIOA->AFR[0] |= 0x0000bbb0;
	GPIOA->AFR[1] &= ~(0xf0000fff);
	GPIOA->AFR[1] |= 0xb0000bbb;
	/* GPIOB mode alterfunc 15,14,13,12,11,10,9,8,5,4,3 */
	GPIOB->MODER &= ~(0xffff0fc0);
	GPIOB->MODER |= 0xaaaa0a80;
	/* Set alternate function mode 0xb port B */
	GPIOB->AFR[0] &= ~(0x00fff000);
	GPIOB->AFR[0] |= 0x00bbb000;
	GPIOB->AFR[1] &= ~(0xffffffff);
	GPIOB->AFR[1] |= 0xbbbbbbbb;
	/* GPIOC mode alterfunc 11,10,9,8,7,6,3,2,1,0 */
	GPIOC->MODER &= ~(0x00fff0ff);
	GPIOC->MODER |= 0x00aaa0aa;
	/* Set alternate function mode 0xb port C */
	GPIOC->AFR[0] &= ~(0xff00ffff);
	GPIOC->AFR[0] |= 0xbb00bbbb;
	GPIOC->AFR[1] &= ~(0x0000ffff);
	GPIOC->AFR[1] |= 0x0000bbbb;
}
/* Config the LCD */
void LCD_Configure(void) {  
  /* Set Bias to 1/3 */
	LCD->CR &= ~(0x3<<5);
	LCD->CR |= 0x2<<5;
	/* Set Duty to 1/4 */
	LCD->CR &= ~(0x7<<2);
	LCD->CR |= 0x3<<2;
	/* Set contrast value 111 */
	LCD->FCR &= ~(0x7<<10);
	LCD->FCR |= 0x7<<10;
	/* Set pulse */
	LCD->FCR &= ~(0x7<<4);
	LCD->FCR |= 0x7<<4;
	/* Enable Mux Segment */
	LCD->CR |= LCD_CR_MUX_SEG;
	/* Select internal voltage */
	LCD->CR &= ~(LCD_CR_VSEL);
	/* Wait until FCRSF flag of LCD_SR is set */
	while(!(LCD->SR & LCD_SR_FCRSR));
	/* Enable LCD by set LCDEN */
	LCD->CR |= LCD_CR_LCDEN;
	/* wait for LCD by check ENS */
	while(!(LCD->SR & LCD_SR_ENS));
	/* wait for booster for RDY in LCD_SR */
	while(!(LCD->SR & LCD_SR_RDY));
}
void LCD_ClearRam(){
	LCD->RAM[0] = 0;
	LCD->RAM[2] = 0;
	LCD->RAM[4] = 0;
	LCD->RAM[6] = 0;
}
void LCD_Display_Name(void){
  // Implement your code here
  // Note: your are required to program LCD_RAM directly. Therefore, you cannot use 
  // LCD_WriteChar() and LCD_Conv_Char_Seg();
	
	while ((LCD->SR & LCD_SR_UDR) != 0); // Wait for Update Display Request Bit
	LCD_ClearRam(); // Clear RAM
	/* Set LCD_RAM to display SONTHI */
	LCD->RAM[0] |= 0x250c3106; //0x1d1a2585; Display NHOM-1
	LCD->RAM[2] |= 0x3e182287; //0x2b208b82;
	LCD->RAM[4] |= 0x00004400; //0x00100000;
	LCD->RAM[6] |= 0x02120100; //0x20200001;
	 
	// Update the LCD display
  // Set the Update Display Request.
  // Each time software modifies the LCD_RAM it must set the UDR bit to transfer the updated
  // data to the second level buffer. The UDR bit stays set until the end of the update and during
  // this time the LCD_RAM is write protected.
  LCD->SR |= LCD_SR_UDR;
  while ((LCD->SR & LCD_SR_UDD) == 0);
}



/**************************************************************************************/
/*    Lab Part 2: Generic Display Function                                            */
/**************************************************************************************/

void LCD_DisplayString(uint8_t* ptr) {
  // Implement your code here
  // You should use use LCD_WriteChar().
	 uint8_t i = 1;

    /* Send the string character by character on lCD */
    while((*ptr != 0) & (i < 7))
    {
        /* Display one character on LCD */
        LCD_WriteChar(ptr, 0, 0, i);
        /* Point on the next character */
        ptr++;
        /* Increment the character counter */
        i++;
    }
}

void LCD_Clear(void) {  
  while ((LCD->SR & LCD_SR_UDR) != 0); // Wait for Update Display Request Bit
	LCD_ClearRam(); // Clear RAM
	// Update the LCD display
  // Set the Update Display Request.
  // Each time software modifies the LCD_RAM it must set the UDR bit to transfer the updated
  // data to the second level buffer. The UDR bit stays set until the end of the update and during
  // this time the LCD_RAM is write protected.
	LCD->SR |= LCD_SR_UDR; 
  while ((LCD->SR & LCD_SR_UDD) == 0);
}

/**************************************************************************************/
/*    The following definitions and functions are provide for you for Part 2          */
/**************************************************************************************/

/* Macros used for set/reset bar LCD bar */
#define BAR0_ON  t_bar[1] |= 8
#define BAR0_OFF t_bar[1] &= ~8
#define BAR1_ON  t_bar[0] |= 8
#define BAR1_OFF t_bar[0] &= ~8
#define BAR2_ON  t_bar[1] |= 2
#define BAR2_OFF t_bar[1] &= ~2
#define BAR3_ON  t_bar[0] |= 2 
#define BAR3_OFF t_bar[0] &= ~2 

/* code for '�' character */
#define C_UMAP 0x6084

/* code for 'm' character */
#define C_mMap 0xb210

/* code for 'n' character */
#define C_nMap 0x2210

/* constant code for '*' character */
#define star 0xA0DD

/* constant code for '-' character */
#define C_minus 0xA000

/* constant code for '/' */
#define C_slatch  0x00c0

/* constant code for � */
#define C_percent_1 0xec00

/* constant code  for small o */
#define C_percent_2 0xb300

#define C_full 0xffdd

/* LCD BAR status: We don't write directly in LCD RAM for save the bar setting */
uint8_t t_bar[2]={0x0,0x0};
    
/*  =========================================================================
                                 LCD MAPPING
    =========================================================================
      A
     _  ----------
COL |_| |\   |J  /|
       F| H  |  K |B
     _  |  \ | /  |
COL |_| --G-- --M--
        |   /| \  |
       E|  Q |  N |C
     _  | /  |P  \|   
DP  |_| -----------  
      D         

 An LCD character coding is based on the following matrix:
      { E , D , P , N   }
      { M , C , COL , DP}
      { B , A , K , J   }
      { G , F , Q , H   }

 The character 'A' for example is:
  -------------------------------
LSB   { 1 , 0 , 0 , 0   }
      { 1 , 1 , 0 , 0   }
      { 1 , 1 , 0 , 0   }
MSB   { 1 , 1 , 0 , 0   }
      -------------------
  'A' =  F    E   0   0 hex

*/

/* Constant table for cap characters 'A' --> 'Z' */
const uint16_t CapLetterMap[26] = {
  /* A      B      C      D      E      F      G      H      I  */
  0xFE00,0x6714,0x1d00,0x4714,0x9d00,0x9c00,0x3f00,0xfa00,0x0014,
  /* J      K      L      M      N      O      P      Q      R  */
  0x5300,0x9841,0x1900,0x5a48,0x5a09,0x5f00,0xFC00,0x5F01,0xFC01,
  /* S      T      U      V      W      X      Y      Z  */
  0xAF00,0x0414,0x5b00,0x18c0,0x5a81,0x00c9,0x0058,0x05c0
};

/* Constant table for number '0' --> '9' */
const uint16_t NumberMap[10] = {
  /* 0      1      2      3      4      5      6      7      8      9  */
  0x5F00,0x4200,0xF500,0x6700,0xEa00,0xAF00,0xBF00,0x04600,0xFF00,0xEF00
};

void LCD_WriteChar(uint8_t* ch, bool point, bool colon, uint8_t position) {
  uint8_t digit[4];     /* Digit frame buffer */
   
  // Convert displayed character in segment in array digit 
  LCD_Conv_Char_Seg(ch, point, colon, digit);

  // Wait until LCD Ready */  
  while ((LCD->SR & LCD_SR_UDR) != 0); // Wait for Update Display Request Bit
  
  switch (position) {
    /* Position 1 on LCD (Digit 1)*/
    case 1:
      LCD->RAM[0] &= 0xcffffffc;
      LCD->RAM[2] &= 0xcffffffc;
      LCD->RAM[4] &= 0xcffffffc;
      LCD->RAM[6] &= 0xcffffffc;

      LCD->RAM[0] |= ((digit[0]& 0x0c) << 26 ) | (digit[0]& 0x03) ; // 1G 1B 1M 1E      
      LCD->RAM[2] |= ((digit[1]& 0x0c) << 26 ) | (digit[1]& 0x03) ; // 1F 1A 1C 1D 
      LCD->RAM[4] |= ((digit[2]& 0x0c) << 26 ) | (digit[2]& 0x03) ; // 1Q 1K 1Col 1P                                                                                                                                    
      LCD->RAM[6] |= ((digit[3]& 0x0c) << 26 ) | (digit[3]& 0x03) ; // 1H 1J 1DP 1N

      break;
    
    /* Position 2 on LCD (Digit 2)*/
    case 2:
      LCD->RAM[0] &= 0xf3ffff03;
      LCD->RAM[2] &= 0xf3ffff03;      
      LCD->RAM[4] &= 0xf3ffff03;
      LCD->RAM[6] &= 0xf3ffff03;
      
      LCD->RAM[0] |= ((digit[0]& 0x0c) << 24 )|((digit[0]& 0x02) << 6 )|((digit[0]& 0x01) << 2 ) ; // 2G 2B 2M 2E    
      LCD->RAM[2] |= ((digit[1]& 0x0c) << 24 )|((digit[1]& 0x02) << 6 )|((digit[1]& 0x01) << 2 ) ; // 2F 2A 2C 2D
      LCD->RAM[4] |= ((digit[2]& 0x0c) << 24 )|((digit[2]& 0x02) << 6 )|((digit[2]& 0x01) << 2 ) ; // 2Q 2K 2Col 2P
      LCD->RAM[6] |= ((digit[3]& 0x0c) << 24 )|((digit[3]& 0x02) << 6 )|((digit[3]& 0x01) << 2 ) ; // 2H 2J 2DP 2N
      
      break;
    
    /* Position 3 on LCD (Digit 3)*/
    case 3:
      LCD->RAM[0] &= 0xfcfffcff;
      LCD->RAM[2] &= 0xfcfffcff;
      LCD->RAM[4] &= 0xfcfffcff;
      LCD->RAM[6] &= 0xfcfffcff;

      LCD->RAM[0] |= ((digit[0]& 0x0c) << 22 ) | ((digit[0]& 0x03) << 8 ) ; // 3G 3B 3M 3E  
      LCD->RAM[2] |= ((digit[1]& 0x0c) << 22 ) | ((digit[1]& 0x03) << 8 ) ; // 3F 3A 3C 3D
      LCD->RAM[4] |= ((digit[2]& 0x0c) << 22 ) | ((digit[2]& 0x03) << 8 ) ; // 3Q 3K 3Col 3P
      LCD->RAM[6] |= ((digit[3]& 0x0c) << 22 ) | ((digit[3]& 0x03) << 8 ) ; // 3H 3J 3DP 3N
      
      break;
    
    /* Position 4 on LCD (Digit 4)*/
    case 4:
      LCD->RAM[0] &= 0xffcff3ff;
      LCD->RAM[2] &= 0xffcff3ff;
      LCD->RAM[4] &= 0xffcff3ff;
      LCD->RAM[6] &= 0xffcff3ff;
      
      LCD->RAM[0] |= ((digit[0]& 0x0c) << 18 ) | ((digit[0]& 0x03) << 10 ) ; // 4G 4B 4M 4E  
      LCD->RAM[2] |= ((digit[1]& 0x0c) << 18 ) | ((digit[1]& 0x03) << 10 ) ; // 4F 4A 4C 4D
      LCD->RAM[4] |= ((digit[2]& 0x0c) << 18 ) | ((digit[2]& 0x03) << 10 ) ; // 4Q 4K 4Col 4P
      LCD->RAM[6] |= ((digit[3]& 0x0c) << 18 ) | ((digit[3]& 0x03) << 10 ) ; // 4H 4J 4DP 4N
      
      break;
    
    /* Position 5 on LCD (Digit 5)*/
    case 5:
      LCD->RAM[0] &= 0xfff3cfff;
      LCD->RAM[2] &= 0xfff3cfff;
      LCD->RAM[4] &= 0xfff3efff;
      LCD->RAM[6] &= 0xfff3efff;

      LCD->RAM[0] |= ((digit[0]& 0x0c) << 16 ) | ((digit[0]& 0x03) << 12 ) ; // 5G 5B 5M 5E  
      LCD->RAM[2] |= ((digit[1]& 0x0c) << 16 ) | ((digit[1]& 0x03) << 12 ) ; // 5F 5A 5C 5D
      LCD->RAM[4] |= ((digit[2]& 0x0c) << 16 ) | ((digit[2]& 0x01) << 12 ) ; // 5Q 5K   5P 
      LCD->RAM[6] |= ((digit[3]& 0x0c) << 16 ) | ((digit[3]& 0x01) << 12 ) ; // 5H 5J   5N
      
      break;
    
    /* Position 6 on LCD (Digit 6)*/
    case 6:
      LCD->RAM[0] &= 0xfffc3fff;
      LCD->RAM[2] &= 0xfffc3fff;
      LCD->RAM[4] &= 0xfffc3fff;
      LCD->RAM[6] &= 0xfffc3fff;

      LCD->RAM[0] |= ((digit[0]& 0x04) << 15 ) | ((digit[0]& 0x08) << 13 ) | ((digit[0]& 0x03) << 14 ) ; // 6B 6G 6M 6E  
      LCD->RAM[2] |= ((digit[1]& 0x04) << 15 ) | ((digit[1]& 0x08) << 13 ) | ((digit[1]& 0x03) << 14 ) ; // 6A 6F 6C 6D
      LCD->RAM[4] |= ((digit[2]& 0x04) << 15 ) | ((digit[2]& 0x08) << 13 ) | ((digit[2]& 0x01) << 14 ) ; // 6K 6Q    6P 
      LCD->RAM[6] |= ((digit[3]& 0x04) << 15 ) | ((digit[3]& 0x08) << 13 ) | ((digit[3]& 0x01) << 14 ) ; // 6J 6H   6N
      
      break;
    
     default:
      break;
  }

  // Refresh LCD bar
  LCD_bar();

  // Update the LCD display
  // Set the Update Display Request.
  // Each time software modifies the LCD_RAM it must set the UDR bit to transfer the updated
  // data to the second level buffer. The UDR bit stays set until the end of the update and during
  // this time the LCD_RAM is write protected.
  LCD->SR |= LCD_SR_UDR; 
  while ((LCD->SR & LCD_SR_UDD) == 0);
}



// Setting bar on LCD, writes bar value in LCD frame buffer 
void LCD_bar(void) {
        
  LCD->RAM[4] &= 0xffff5fff;
  LCD->RAM[6] &= 0xffff5fff;
  
  /* bar 1, bar 3 */
  LCD->RAM[4] |= (uint32_t)(t_bar[0]<<12);
  
  /* bar 0, bar 2 */
  LCD->RAM[6] |= (uint32_t)(t_bar[1]<<12);
}

// Converts an ascii char to the a LCD digit
static void LCD_Conv_Char_Seg(uint8_t* c, bool point, bool colon, uint8_t* digit) {
  uint16_t ch = 0 ;
  uint8_t i,j;
  
  switch (*c) {
    case ' ' : 
      ch = 0x00;
      break;
    
    case '*':
      ch = star;
      break;
                  
    case '?':
      ch = C_UMAP;
      break;
    
    case 'm' :
      ch = C_mMap;
      break;
                  
    case 'n' :
      ch = C_nMap;
      break;          
                  
    case '-' :
      ch = C_minus;
      break;
      
    case '/' :
      ch = C_slatch;
      break;  
      
//  case '?':
//    ch = C_percent_1;
//    break;  

    case '%' :
      ch = C_percent_2; 
      break;
      
    case 255 :
      ch = C_full;
      break ;
    
    case '0':
    case '1':
    case '2':
    case '3':
    case '4':
    case '5':
    case '6':
    case '7':
    case '8':
    case '9':      
      ch = NumberMap[*c-0x30];    
      break;
          
    default:
      /* The character c is one letter in upper case*/
      if ( (*c < 0x5b) && (*c > 0x40) ) {
        ch = CapLetterMap[*c - 'A'];
      }
      /* The character c is one letter in lower case*/
      if ( (*c <0x7b) && ( *c> 0x60) ) {
        ch = CapLetterMap[*c - 'a'];
      }
      break;
  }
       
  /* Set the digital point can be displayed if the point is on */
  if (point) {
    ch |= 0x0002;
  }

  /* Set the "COL" segment in the character that can be displayed if the colon is on */
  if (colon) {
    ch |= 0x0020;
  }    

  for (i = 12,j=0; j<4; i-=4,j++) {
    digit[j] = (ch >> i) & 0x0f; //To isolate the less signifiant dibit
  }
}
